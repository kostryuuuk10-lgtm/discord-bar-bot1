module.exports = {
  TOKEN: process.env.TOKEN,
  MONGO_URI: process.env.MONGO_URI,
  GROQ_API_KEY: process.env.GROQ_API_KEY,
  HF_API_KEY: process.env.HF_API_KEY,
  OWNER_ID: process.env.OWNER_ID,
  LOG_CHANNEL_ID: process.env.LOG_CHANNEL_ID
};
